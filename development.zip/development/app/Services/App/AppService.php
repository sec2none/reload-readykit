<?php


namespace App\Services\App;


use App\Services\Core\BaseService;

class AppService extends BaseService
{

}