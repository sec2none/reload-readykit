<?php


namespace App\Hooks\Table;


use App\Helpers\Core\Traits\InstanceCreator;
use App\Hooks\HookContract;

class WhileCustomTableDeleting extends HookContract
{
    use InstanceCreator;

    public function handle()
    {
        // TODO: Implement handle() method.
    }
}